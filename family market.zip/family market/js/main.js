$(document).ready(function(){
    $(".twsel").hide();
    $(".push").click(function(){
        $(".twsel").toggle().siblings().remove(".a");

    
    } );
  


});